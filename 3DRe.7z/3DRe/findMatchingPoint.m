% near_point is the nearest point from the plane;
% arr is the arrow of near_point;
% find_lable is a lable of weather find near_point;
function [near_point,arr,find_lable] = findMatchingPoint(zuobiao,plantfactor)
find_lable=true;
A=plantfactor(1);
B=plantfactor(2);
C=plantfactor(3);
D=plantfactor(4);
[row,~]=size(zuobiao);
start_pos=1;
end_pos=row;
middle_pos=round((start_pos+end_pos)/2);
while((middle_pos~=start_pos)&&(middle_pos~=end_pos))
    P1=zuobiao(start_pos,:);
    x= P1(1);y= P1(2);z= P1(3);
    lable_s=A*x+B*y+C*z+D;

    P2=zuobiao(end_pos,:);
    x= P2(1);y= P2(2);z= P2(3);
    lable_e=A*x+B*y+C*z+D;

    P3=zuobiao(middle_pos,:);
    x= P3(1);y= P3(2);z= P3(3);
    lable_m=A*x+B*y+C*z+D;
    if((lable_s*lable_m)<0)
        end_pos=middle_pos;
        middle_pos=round((end_pos+start_pos)/2);
    elseif(lable_e*lable_m<0)
        start_pos=middle_pos;
        middle_pos=round((start_pos+end_pos)/2);
    else
        find_lable=false;
        break;
    end
end
P_start=zuobiao(start_pos,:);
x= P_start(1);y= P_start(2);z= P_start(3);
distance_s=abs(A*x+B*y+C*z+D)/norm([A B C]);

P_end=zuobiao(end_pos,:);
x= P_end(1);y= P_end(2);z= P_end(3);
distance_e=abs(A*x+B*y+C*z+D)/norm([A B C]);
if find_lable
%     display(distance_e);
%     display(distance_s);
%     display("***************");
end
arr=P_start-P_end;
arr=arr/norm(arr);
if distance_s>distance_e
    near_point=P_end;
else
    near_point=P_start;
end

end
