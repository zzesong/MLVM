%% Sction IV. A. Direct Solution Method
load("example2_data.mat");
%% Determine the axis direction according to the side profile
luntai_point=sideProfile;
mean_sideProfile=mean(sideProfile,1);
norm_sideProfile=sideProfile-mean_sideProfile;
cov_mean_sideProfile=norm_sideProfile'*norm_sideProfile/(size(norm_sideProfile,1));
[V,D] = eig(cov_mean_sideProfile);
r1=V(:,1)';
%% 
[R,Oc] = optimizeAxis(treadProfile1,treadProfile2,treadProfile3,r1,1);% Solving Axis

% Correcting Profile
r1=-R(3,:);  
p1=Oc;
num_l=size(completeProfile1,1);
PL=[];
PM=[];
PR=[];
q=[0,0];
for i=1:1:num_l                          
p=completeProfile1(i,:);                                    
q(2)=norm(cross((p1-p),r1));
q(1)=(p1-p)*r1';
PL=[PL;q];
end
scatter(PL(:,1),PL(:,2),50,'black',".");
hold on;

num_m=size(completeProfile2,1);
for i=1:1:num_m
p=completeProfile2(i,:);                                     
q(2)=norm(cross((p1-p),r1));
q(1)=(p1-p)*r1';
PM=[PM;q];
end
scatter(PM(:,1),PM(:,2),50,'magenta',".");
hold on;

num_r=size(completeProfile3,1);
for i=1:1:num_r
p=completeProfile3(i,:);                                    
q(2)=norm(cross((p1-p),r1));
q(1)=(p1-p)*r1';
PR=[PR;q];
end
scatter(PR(:,1),PR(:,2),50,'c',".");
hold on;
axis equal;
%% 
figure;
scatter3(completeProfile1(:,1),completeProfile1(:,2),completeProfile1(:,3),"G",".");
hold on;
scatter3(completeProfile2(:,1),completeProfile2(:,2),completeProfile2(:,3),"B",".");
hold on;
scatter3(completeProfile3(:,1),completeProfile3(:,2),completeProfile3(:,3),"R",".");
hold on;
num_r=size(completeProfile3,1);
for i=1:2:num_r
p=completeProfile3(i,:);                                     %%%%截面上坐标点
s1=cross(r1,(p-Oc));
s2=cross(r1,s1);
s2=s2/norm(s2);
Poi=p(1:2)'-p1(1:2)';
A=[-s2(1:2)' r1(1:2)'];
K=A\Poi;
P_o=p+K(1)*s2;
draw_Circle(P_o,r1,p);
end
axis equal




