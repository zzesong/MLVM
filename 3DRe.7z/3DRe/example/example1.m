%% Sction IV. B. Iterative Optimization Algorithm
load("example1_data.mat");

r1=[0.277185647007666	0.877644657727008	0.391034489343568];
[R,Oc] = optimizeAxis(treadProfile1,treadProfile2,treadProfile3,r1,40);% Solving Axis
%% 

% Correcting Profile
r1=R(3,:);  
p1=Oc;
num_l=size(treadProfile1,1);
PL=[];
PM=[];
PR=[];
%% 

q=[0,0];
for i=1:1:num_l                          
p=treadProfile1(i,:);                                    
q(2)=norm(cross((p1-p),r1));
q(1)=(p1-p)*r1';
PL=[PL;q];
end
scatter(PL(:,1),PL(:,2),50,'black',".");
hold on;
%% 

num_m=size(treadProfile2,1);
for i=1:1:num_m
p=treadProfile2(i,:);                                     
q(2)=norm(cross((p1-p),r1));
q(1)=(p1-p)*r1';
PM=[PM;q];
end
scatter(PM(:,1),PM(:,2),50,'magenta',".");
hold on;
%% 

num_r=size(treadProfile3,1);
for i=1:1:num_r
p=treadProfile3(i,:);                                    
q(2)=norm(cross((p1-p),r1));
q(1)=(p1-p)*r1';
PR=[PR;q];
end
scatter(PR(:,1),PR(:,2),50,'c',".");
hold on;
axis equal;

%% According to the estimated axis, reconstruct 3d with the general cross-section profile
figure;
scatter3(treadProfile1(:,1),treadProfile1(:,2),treadProfile1(:,3),"g",".");
hold on;
scatter3(treadProfile2(:,1),treadProfile2(:,2),treadProfile2(:,3),"b",".");
hold on;
scatter3(treadProfile3(:,1),treadProfile3(:,2),treadProfile3(:,3),"r",".");
hold on;
num_r=size(treadProfile3,1);
for i=1:2:num_r
p=treadProfile3(i,:);                                     %%%%截面上坐标点
s1=cross(r1,(p-Oc));
s2=cross(r1,s1);
s2=s2/norm(s2);
Poi=p(1:2)'-p1(1:2)';
A=[-s2(1:2)' r1(1:2)'];
K=A\Poi;
P_o=p+K(1)*s2;
draw_Circle(P_o,r1,p);
end
axis equal




