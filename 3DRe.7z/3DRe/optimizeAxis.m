function [R,Oc] = optimizeAxis(camera_l_cor,camera_m_cor,camera_r_cor,r1,time)
%% Initializing axis direction
% r1=[0.277185647007666	0.877644657727008	0.391034489343568];
r1=r1/norm(r1);
r3=[0,1,0];
r2=cross(r1,r3);
r2=r2/norm(r2);
r3=cross(r1,r2);
r3=r3/norm(r3);
R=[r2' r3' r1']';
old_err=99999999999999999999999999;
times=0;
%% 
while times<time
%% Establish matching points set
times=times+1
num_l=size(camera_l_cor,1);
fix_pls=[];
near_pms=[];
arr_pms=[];
near_prs=[];
arr_prs=[];
r1=R(3,:);
for i=1:1:num_l
    p1=camera_l_cor(i,:);
    d=-r1*p1';
    plantfactor=[r1';d];
    [near_pm,arr_m,lable_m]=findMatchingPoint(camera_m_cor,plantfactor);
    [near_pr,arr_r,lable_r]=findMatchingPoint(camera_r_cor,plantfactor);
    if lable_m&&lable_r
        fix_pls=[fix_pls;p1];
        near_pms=[near_pms;near_pm];
        arr_pms=[arr_pms;arr_m];
        near_prs=[near_prs;near_pr];
        arr_prs=[arr_prs;arr_r];
    end
end

Kms=[];
Krs=[];
Init_pls=(R*fix_pls')';
Init_pms=[];
Init_prs=[];
PLS=(R*fix_pls')';
PMS=(R*near_pms')';
PRS=(R*near_prs')';
arr_ms=(R*arr_pms')';
arr_rs=(R*arr_prs')';
for i=1:size(fix_pls,1)
    Pl=PLS(i,:);
    Pm=PMS(i,:);
    Pr=PRS(i,:);
    Am=arr_ms(i,:);
    Ar=arr_rs(i,:);
    km=(Pl(3)-Pm(3))/Am(3);
    Kms=[Kms;km];
    kr=(Pl(3)-Pr(3))/Ar(3);
    Krs=[Krs;kr];
    Pm_=Pm+km*Am;
    Pr_=Pr+kr*Ar;
    Init_pms=[Init_pms;Pm_];
    Init_prs=[Init_prs;Pr_];
end
Ps= [Init_pls Init_pms Init_prs];
%% Solved the point on the axis
Ps_square=Ps.*Ps;
SP=[];
SPS=[];
for i=1:1:size(fix_pls,1)
    sum_poi=[0,0,0];
    sum_poisq=[0,0,0];
    for k=1:3
        poi=Ps(i,3*k-2:3*k);
        poisq=Ps_square(i,3*k-2:3*k);
        sum_poi=sum_poi+poi;
        sum_poisq=sum_poisq+poisq;
    end
    SP=[SP;sum_poi];
    SPS=[SPS;sum_poisq];
end
hs=[];
gs=[];
fs=[];
es=[];
for k=1:3
    poi=Ps(:,3*k-2:3*k);
    poisq=Ps_square(:,3*k-2:3*k);
    hgs=poi-(1/3)*SP;
    hs=[hs;hgs(:,1)];
    gs=[gs;hgs(:,2)];
    fs=[fs;poisq(:,1)+poisq(:,2)-(1/3)*(SPS(:,1)+SPS(:,2))];
end
H=[hs,gs];
F=-fs;
O=-0.5*((H'*H)\H'*F);
Oa=[O;0];
Oc=R'*Oa;
Oa=Oa';
Oc=Oc';
if(times==time)
    break;
end
%% Solving the incremental equation about axis direction

size_pms=size(Init_pms,1);
jacobi=[0;0];
Hasson=[0,0;0,0];
errs=0;
dw=0;

for i=1:1:size_pms
    p1=Init_pls(i,:)-Oa;
    p2=Init_pms(i,:)-Oa;
    p3=Init_prs(i,:)-Oa;
    sum_square=(p1(1)^2+p2(1)^2+p3(1)^2)+(p1(2)^2+p2(2)^2+p3(2)^2);
    err1=p1(1)^2+p1(2)^2-sum_square/3;
    err2=p2(1)^2+p2(2)^2-sum_square/3;
    err3=p3(1)^2+p3(2)^2-sum_square/3;

    errs=errs+err1*err1+err2*err2+err3*err3;
    df1dx1=2*(1-1/3)*p1(1);
    df1dy1=2*(1-1/3)*p1(2);
    df1dx2=(-2/3)*p2(1);
    df1dy2=(-2/3)*p2(2);
    df1dx3=(-2/3)*p3(1);
    df1dy3=(-2/3)*p3(2);

    df2dx1=(-2/3)*p1(1);
    df2dy1=(-2/3)*p1(2);
    df2dx2=2*(1-1/3)*p2(1);
    df2dy2=2*(1-1/3)*p2(2);
    df2dx3=(-2/3)*p3(1);
    df2dy3=(-2/3)*p3(2);

    df3dx1=(-2/3)*p1(1);
    df3dy1=(-2/3)*p1(2);
    df3dx2=(-2/3)*p2(1);
    df3dy2=(-2/3)*p2(2);
    df3dx3=2*(1-1/3)*p3(1);
    df3dy3=2*(1-1/3)*p3(2);

    df1dp1=[df1dx1 df1dy1];
    df1dp2=[df1dx2 df1dy2];
    df1dp3=[df1dx3 df1dy3];

    df2dp1=[df2dx1 df2dy1];
    df2dp2=[df2dx2 df2dy2];
    df2dp3=[df2dx3 df2dy3];

    df3dp1=[df3dx1 df3dy1];
    df3dp2=[df3dx2 df3dy2];
    df3dp3=[df3dx3 df3dy3];

    arr2=arr_pms(i,:);
    arr3=arr_prs(i,:);
    k2=Kms(i);
    k3=Krs(i);
    p1=fix_pls(i,:);
    p2=near_pms(i,:);
    p3=near_prs(i,:);

    dp1dw=-cross_mat(R*(p1-Oc)');
    dp2dw=-cross_mat(R*(p2+k2*arr2-Oc)')+R*arr2'*([0,0,1]*(cross_mat(R*(p2+k2*arr2-p1)'))/([0,0,1]*R*arr2'));
    dp3dw=-cross_mat(R*(p3+k3*arr3-Oc)')+R*arr3'*([0,0,1]*(cross_mat(R*(p3+k3*arr3-p1)'))/([0,0,1]*R*arr3'));
    Emat=[1,0,0;0,1,0];
    derr1dw=df1dp1*Emat*dp1dw+df1dp2*Emat*dp2dw+df1dp3*Emat*dp3dw;
    derr2dw=df2dp1*Emat*dp1dw+df2dp2*Emat*dp2dw+df2dp3*Emat*dp3dw;
    derr3dw=df3dp1*Emat*dp1dw+df3dp2*Emat*dp2dw+df3dp3*Emat*dp3dw;
    dw=dw+derr1dw+derr2dw+derr3dw;
    derr1dw=derr1dw*[1,0;0,1;0,0];
    derr2dw=derr2dw*[1,0;0,1;0,0];
    derr3dw=derr3dw*[1,0;0,1;0,0];

    Hasson=Hasson+derr1dw'*derr1dw+derr2dw'*derr2dw+derr3dw'*derr3dw;

    b_err=derr1dw'*err1'+derr2dw'*err2'+derr3dw'*err3';
    jacobi=jacobi-b_err;
end

w1= inv(Hasson)*jacobi;
gain=(errs-old_err);
%% update axis direction
w=1*[w1;0];
norm_w=norm(w);
% if norm_w<0.01
% w= 0.0005*w/norm_w;
% end
update_r=[1,0,0;0,1,0;0,0,1]+(sin(norm_w)/norm_w)*cross_mat(w)+...
    ((1-cos(norm_w))/norm_w^2)*cross_mat(w)*cross_mat(w);
old_R=R;
R=update_r*R;
old_err=errs;

end
%%
    function [CMatrix] = cross_mat(mat)
    CMatrix=[0,-mat(3),mat(2)
        mat(3),0,-mat(1)
        -mat(2),mat(1),0];
    end
end